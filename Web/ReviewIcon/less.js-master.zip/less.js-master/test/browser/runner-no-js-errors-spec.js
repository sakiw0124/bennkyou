describe("less.js javascript disabled error tests", function() {
    testLessErrorsInDocument();
});
